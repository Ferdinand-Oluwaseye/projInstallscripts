exports.app = {
    PORT : 8080,
    MONGODB_URI: 'mongodb://mongo:27017/userDatabase',
    logErrors: true
};
