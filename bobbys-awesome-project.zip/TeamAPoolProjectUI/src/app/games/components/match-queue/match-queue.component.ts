import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-match-queue',
  templateUrl: './match-queue.component.html',
  styleUrls: ['./match-queue.component.scss']
})
export class MatchQueueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  clicked(){

  }
}
