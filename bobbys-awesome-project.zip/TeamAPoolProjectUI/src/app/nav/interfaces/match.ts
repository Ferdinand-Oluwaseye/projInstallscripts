export interface Match {
    playerOne: string,
    playerTwo: string,
    queueNumber: Number
}
