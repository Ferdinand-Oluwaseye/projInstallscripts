export interface MatchInterface {

playerOne : string;
playerTwo : string;
}
