export interface PlayerInterface {
    username: string,
    firstName: string,
    surname: string,
    password: string,
    wins: Number,
    losses: Number,
    totalGames:Number,
    matchUps: Object; 
    //     opponentUsername: string,
    //     results : Object {
    //         wins: Number,
    //         losses: Number
    //     }
    // }
}
