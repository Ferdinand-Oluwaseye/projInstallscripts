import { Match } from './match';

describe('Match', () => {
  it('should create an instance', () => {
    expect(new Match()).toBeTruthy();
  });
});
