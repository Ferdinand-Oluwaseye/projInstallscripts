export interface IUser {
    username: string,
    firstName: string,
    surname: string
}
