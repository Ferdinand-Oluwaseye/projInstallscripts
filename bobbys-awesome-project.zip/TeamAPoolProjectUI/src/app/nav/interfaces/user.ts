export interface User {
    userId: string,
    username: string,
    firstName: string,
    surname: string
}

//example from json
// export interface User {
//     userId: number,
//     id: number,
//     title: string,
//     body: string
// }