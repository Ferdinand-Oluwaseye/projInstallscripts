import { MatchInterface } from './match-interface';

describe('MatchInterface', () => {
  it('should create an instance', () => {
    expect(new MatchInterface()).toBeTruthy();
  });
});
